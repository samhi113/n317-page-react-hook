export default function Pokemon() {
  return (
    <main>
      <h1>Pokemon Page</h1>
    </main>
  );
}
